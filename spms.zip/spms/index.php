<?php 
header("location:./admin");
?>